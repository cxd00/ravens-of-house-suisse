package com.example.demo;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

//class to read in excel file and transfer data to a HashMap where according values can  be quickly found
public class SalesDataReader { 
	//excel file linked to be read
	private static final String FILE_NAME = "RFXSalesAxeData.xlsx";
	//uses hash map for efficient runtime
	private HashMap<String, ISINValues> map = new HashMap<>(); 
	
	{ //initialization block to run when SalesDataReader object is created

        try {
            //reads file as an input stream
            FileInputStream excelFile = new FileInputStream(new File(FILE_NAME));
            Workbook workbook = new XSSFWorkbook(excelFile);
            Sheet datatypeSheet = workbook.getSheetAt(0);
            Iterator<Row> iterator = datatypeSheet.iterator(); //creates iterator over sheet

            while (iterator.hasNext()) { //iterates through each row of sheet
            	Row currentRow = iterator.next();
            	if(currentRow.getRowNum()==0){
            		continue; //skips the row if row number is 0, as these are heading 
            	}
                ArrayList<Cell> list = new ArrayList<>(); //list to be used to construct ISINValues object
               
                for(int i = 1; i < currentRow.getLastCellNum(); i++) {
                	if(i != 3) {
                		//adds cell based on location in Excel sheet 
                		list.add(currentRow.getCell(i)); 
                	}
                }
                String currentISIN;
                try {
                	currentISIN = currentRow.getCell(3).getStringCellValue();
                } catch(NullPointerException e) { //in case where ISIN cell in empty
                	currentISIN = " ";  //avoid nullPointerException
                }
                
                ISINValues values = new ISINValues(list); //initializes values for map
                map.put(currentISIN, values); //maps values to appropriate ISIN key
            }
        } catch (FileNotFoundException e) { //accounts for file not found
        	System.out.println("File not found in the specified path");
            e.printStackTrace(); 
        } catch (IOException e) {
            e.printStackTrace(); 
        }

    }
	
    //returns private map variable
    public HashMap<String, ISINValues> getMap(){ 
    	return map;
    }
    
    //allows for easy access to all values given any ISIN key, returns list given ISIN key parameter
    public List<String> getAllValues(String ISIN){ 
    	return map.get(ISIN).getValuesAsList();
    }
	
}