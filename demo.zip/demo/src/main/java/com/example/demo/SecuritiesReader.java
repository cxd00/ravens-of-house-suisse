package com.example.demo;

import org.apache.poi.ss.usermodel.*;

import java.util.List;

public class SecuritiesReader {

    private final long id;
    private final String isin;

    public SecuritiesReader(long id, String isin) {
        this.id = id;
        this.isin = isin;
    }

    public long getId() {
        return id;
    }

    public List<String> getContent() {
    	return new SalesDataReader().getAllValues(isin);
    }
    
    
}
