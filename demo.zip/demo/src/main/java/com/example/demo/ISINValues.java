package com.example.demo;

import java.util.LinkedList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;

/*public class representing all different data associated with particular ISIN value, used 
 * as the value to the ISIN key in hashMap created to store and find data in 
 * SalesDataReader class
 */
public class ISINValues {
	
	//private instance variables representing 31 different aspects of the data
	private String CSSide;
	private String product;
	private String CUSIP;
	private double quantity;
	private String level; //level is represented as double at times; this was accordingly handled in the constructor
	private String CCY;
	private String securityID;
	private double zSpread;
	private double yield;
	private double bSpread;
	private String BMKName;
	private double price;
	private String deskRegion;
	private double score;
	private double feedback;
	private String book;
	private boolean hybrid;
	private boolean seniority;
	private String collateralType;
	private boolean perpetual;
	private boolean callable;
	private String nextCall;
	private String composition;
	private String sAndP;
	private String moodys;
	private String fitch;
	private String industry;
	private String countryOfRisk;
	private String countryOfIssue;
	private String issuer;
	private String created;
	private List<Cell> valuesAsList; //Conveniently adds all values into List
	
	/*public constructor takes generic parameter of List of Cells that is created and passed in
	 * SalesDataReader class and uses it to properly assign values to each instance 
	 * variable
	 * If passed in as ArrayList, as done in SalesDataReader class, allows for O(1) access to each element in parameter 
	 */
	public ISINValues(List<Cell> list) {
		try {
			CSSide = list.get(0).getStringCellValue();
			product = list.get(1).getStringCellValue();
			CUSIP = list.get(2).getStringCellValue();
			quantity = list.get(3).getNumericCellValue();
			try {
				level = list.get(4).getStringCellValue();
			} catch(IllegalStateException e) { //when level is represented as a Double instead of a String
				level = Double.toString(list.get(4).getNumericCellValue()) ;
			}
			CCY = list.get(5).getStringCellValue();
			securityID = list.get(6).getStringCellValue();
			zSpread = list.get(7).getNumericCellValue();
			yield = list.get(8).getNumericCellValue();
			bSpread = list.get(9).getNumericCellValue();
			BMKName = list.get(10).getStringCellValue();
			price = list.get(11).getNumericCellValue();
			deskRegion = list.get(12).getStringCellValue();
			score = list.get(13).getNumericCellValue();
			feedback = list.get(14).getNumericCellValue();
			book = list.get(15).getStringCellValue();
			hybrid = list.get(16).getBooleanCellValue();
			seniority = list.get(17).getBooleanCellValue();
			collateralType = list.get(18).getStringCellValue();
			perpetual = list.get(19).getBooleanCellValue();
			callable = list.get(20).getBooleanCellValue();
			nextCall = list.get(21).getStringCellValue();
			composition = list.get(22).getStringCellValue();
			sAndP = list.get(23).getStringCellValue();
			moodys = list.get(24).getStringCellValue();
			fitch = list.get(25).getStringCellValue();
			industry = list.get(26).getStringCellValue();
			countryOfRisk = list.get(27).getStringCellValue();
			countryOfIssue = list.get(28).getStringCellValue();
			issuer = list.get(29).getStringCellValue();
			created = list.get(30).getStringCellValue();
		} catch(NullPointerException e) { //in case cell in data sheet was empty 
			//do nothing; will simply initialize the variable as null since there is no data for that value
			//this is handled accordingly in front end implementation
		}
		valuesAsList = list;
	}
	/*standard getters and setters for all instance variables allows map in SalesDataReader
	 * to access and change any values quickly in 0(1) running time using ISIN key
	 */
	public String getCSSide() {
		return CSSide;
	}

	public void setCSSide(String cSSide) {
		CSSide = cSSide;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getCUSIP() {
		return CUSIP;
	}

	public void setCUSIP(String cUSIP) {
		CUSIP = cUSIP;
	}

	public double getQuantity() {
		return quantity;
	}

	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getCCY() {
		return CCY;
	}

	public void setCCY(String cCY) {
		CCY = cCY;
	}

	public String getSecurityID() {
		return securityID;
	}

	public void setSecurityID(String securityID) {
		this.securityID = securityID;
	}

	public double getzSpread() {
		return zSpread;
	}

	public void setzSpread(double zSpread) {
		this.zSpread = zSpread;
	}

	public double getYield() {
		return yield;
	}

	public void setYield(double yield) {
		this.yield = yield;
	}

	public double getbSpread() {
		return bSpread;
	}

	public void setbSpread(double bSpread) {
		this.bSpread = bSpread;
	}

	public String getBMKName() {
		return BMKName;
	}

	public void setBMKName(String bMKName) {
		BMKName = bMKName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getDeskRegion() {
		return deskRegion;
	}

	public void setDeskRegion(String deskRegion) {
		this.deskRegion = deskRegion;
	}

	public double getScore() {
		return score;
	}

	public void setScore(double score) {
		this.score = score;
	}

	public double getFeedback() {
		return feedback;
	}

	public void setFeedback(double feedback) {
		this.feedback = feedback;
	}

	public String getBook() {
		return book;
	}

	public void setBook(String book) {
		this.book = book;
	}

	public boolean isHybrid() {
		return hybrid;
	}

	public void setHybrid(boolean hybrid) {
		this.hybrid = hybrid;
	}

	public boolean isSeniority() {
		return seniority;
	}

	public void setSeniority(boolean seniority) {
		this.seniority = seniority;
	}

	public String getCollateralType() {
		return collateralType;
	}

	public void setCollateralType(String collateralType) {
		this.collateralType = collateralType;
	}

	public boolean isPerpetual() {
		return perpetual;
	}

	public void setPerpetual(boolean perpetual) {
		this.perpetual = perpetual;
	}

	public boolean isCallable() {
		return callable;
	}

	public void setCallable(boolean callable) {
		this.callable = callable;
	}

	public String getNextCall() {
		return nextCall;
	}

	public void setNextCall(String nextCall) {
		this.nextCall = nextCall;
	}

	public String getComposition() {
		return composition;
	}

	public void setComposition(String composition) {
		this.composition = composition;
	}

	public String getsAndP() {
		return sAndP;
	}

	public void setsAndP(String sAndP) {
		this.sAndP = sAndP;
	}

	public String getMoodys() {
		return moodys;
	}

	public void setMoodys(String moodys) {
		this.moodys = moodys;
	}

	public String getFitch() {
		return fitch;
	}

	public void setFitch(String fitch) {
		this.fitch = fitch;
	}

	public String getIndustry() {
		return industry;
	}

	public void setIndustry(String industry) {
		this.industry = industry;
	}

	public String getCountryOfRisk() {
		return countryOfRisk;
	}

	public void setCountryOfRisk(String countryOfRisk) {
		this.countryOfRisk = countryOfRisk;
	}

	public String getCountryOfIssue() {
		return countryOfIssue;
	}

	public void setCountryOfIssue(String countryOfIssue) {
		this.countryOfIssue = countryOfIssue;
	}

	public String getIssuer() {
		return issuer;
	}

	public void setIssuer(String issuer) {
		this.issuer = issuer;
	}

	public String getCreated() {
		return created;
	}

	public void setCreated(String created) {
		this.created = created;
	}
	
	public List<String> getValuesAsList(){
		List<String> values = new LinkedList<String>(); //set up as LinkedList for quick adding
		for(int i = 0; i < valuesAsList.size(); i++) {
			try {
				values.add(valuesAsList.get(i).getStringCellValue());
			} catch(IllegalStateException e) {
				try {
					values.add(Double.toString(valuesAsList.get(i).getNumericCellValue()));
				} catch(IllegalStateException f) {
					values.add(Boolean.toString(valuesAsList.get(i).getBooleanCellValue()));
				}
			} catch(NullPointerException e) {
				values.add(" ");
			}
		}
		return values;
	}

}