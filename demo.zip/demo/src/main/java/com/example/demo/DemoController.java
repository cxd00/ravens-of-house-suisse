package com.example.demo;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DemoController {

    @RequestMapping("/greeting")
    public ChatReader greeting(@RequestParam(value="name", defaultValue="Hello") String rowNum) {
        return new ChatReader(1,26); //replace 20 with rowNum-1
    }
    
    @RequestMapping("/greeting2")
    public SecuritiesReader greeting2(@RequestParam(value="name", defaultValue="World") String isin) {
    	return new SecuritiesReader(1, "US675232AB89");
    }
}