package com.example.demo;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.*;

public class ChatReader {

    private final long id;
    private final int rowNum;

    public ChatReader(long id, int rowNum) {
        this.id = id;
        this.rowNum = rowNum;
    }

    public long getId() {
        return id;
    }

    public List<String> getContent() {
    	String sender = null;
		String recip = null;
		String msg = null;
		List<String> content = new ArrayList<String>();
		
    	try {
			File excelFile = new File("GoTBBGData.xls"); //import file as File to save memory
			FileInputStream fis = new FileInputStream(excelFile);
			
			HSSFWorkbook workbook = new HSSFWorkbook(fis);//get specific sheet
			HSSFSheet sheet = workbook.getSheetAt(0);
			
			//iterate over the rows
			
			String test1 = "JonSnow3";
			String test2 = "RickonStark3"; //for testing purposes: only convos b/w Jon3 and Rickon3
			
			Row row = sheet.getRow(rowNum);
			
			sender = row.getCell(3).toString();
			recip = row.getCell(4).toString();
			
			try { //to deal with null messages
				msg = row.getCell(28).toString();
			} catch (NullPointerException e) {
				msg = "";
			}
			
			if ((sender.equals(test1)&&recip.equals(test2)) || (recip.equals(test1)&&sender.equals(test2))) { 
				//save the users, time stamps, and message content
				content.add(sender);
				content.add(recip);
				content.add(msg);
				findISIN(msg, content);
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return content;
    }
    
    public void findISIN(String msg, List<String> al) {
		String msgCopy = msg;

		Pattern isinReg = Pattern.compile("([A-Z][A-Z]\\d{10}?)"); //regular expression for an ISIN
		Matcher matcher = isinReg.matcher(msgCopy);
		
		StringBuffer sb = new StringBuffer();
		
		while(matcher.find()) {
			if (sb.indexOf(matcher.group(1))== -1) {
				sb.append(" - ").append(matcher.group(1));
				al.add(matcher.group(1));
			}
		}
		
	}
}
