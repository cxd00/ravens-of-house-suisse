package com.example.demo;

import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.util.Iterator;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
 
/**
 * @author Crunchify.com
 */
 
public class JSONReader {
 
    @SuppressWarnings("unchecked")
    public static void main(String[] args) {
        JSONParser parser = new JSONParser();
 
        try {
 
            JSONObject jsonObject = (JSONObject) parser.parse(new InputStreamReader(new FileInputStream("GoTBBGData.json")));
 
            Object messages = new JSONArray();
            messages = jsonObject.get("messages");
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}